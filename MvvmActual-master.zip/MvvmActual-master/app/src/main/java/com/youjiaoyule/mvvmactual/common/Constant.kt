package com.youjiaoyule.mvvmactual.common

/**
 *  @author RenGX on 2020/6/10
 *
 */
object Constant {
    var BASE_URL = "https://api.wdkid.com.cn"
    var TOKEN = ""

    const val SUCCESS = 20000
    const val NOT_LOGIN = -1001
}