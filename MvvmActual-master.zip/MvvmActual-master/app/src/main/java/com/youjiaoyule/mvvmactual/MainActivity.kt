package com.youjiaoyule.mvvmactual

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.youjiaoyule.mvvmactual.net.RetrofitFactory
import com.youjiaoyule.mvvmactual.net.RxRestService

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



    }
}